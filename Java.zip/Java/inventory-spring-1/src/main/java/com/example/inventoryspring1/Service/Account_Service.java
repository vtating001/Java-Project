package com.example.inventoryspring1.Service;

import java.util.List;
import java.util.Optional;

import com.example.inventoryspring1.Models.Account;

public interface Account_Service {

	Account saveAccount(Account account);
	List<Account> getAllAccounts();
	Account getAccountById(long id);
	Account updateAccount(Account account);
	void deleteAccount(Account account);	
	Optional<Account> findByUsername(String username);
}
