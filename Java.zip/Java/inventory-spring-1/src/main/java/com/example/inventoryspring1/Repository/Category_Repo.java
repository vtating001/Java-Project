package com.example.inventoryspring1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventoryspring1.Models.Category;

public interface Category_Repo extends JpaRepository<Category, Long>{

}
