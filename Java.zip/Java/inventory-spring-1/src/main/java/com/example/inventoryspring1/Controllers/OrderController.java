package com.example.inventoryspring1.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventoryspring1.Models.Order;
import com.example.inventoryspring1.Service.Order_Service;

@RestController
public class OrderController {

	@Autowired
	private Order_Service orderService;

	public OrderController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderController(Order_Service orderService) {
		super();
		this.orderService = orderService;
	}
	//Create
	@PostMapping("/api/order/add")
	public ResponseEntity<List<Order>> saveOrder(@RequestBody List<Order> order){
		   List<Order> savedOrders = orderService.saveOrder(order);
		    return new ResponseEntity<>(savedOrders, HttpStatus.CREATED);
	}
	
}
