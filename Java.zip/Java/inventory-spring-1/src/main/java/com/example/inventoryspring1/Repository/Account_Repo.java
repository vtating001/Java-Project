package com.example.inventoryspring1.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventoryspring1.Models.Account;

public interface Account_Repo extends JpaRepository<Account, Long>{

	   Optional<Account> findByUsername(String username);
}
