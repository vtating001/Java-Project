package com.example.inventoryspring1.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventoryspring1.Models.Account;
import com.example.inventoryspring1.Service.Account_Service;

@RestController
public class AccountController {
		
		@Autowired
		private Account_Service accountService;

		
		public AccountController() {
			super();
			// TODO Auto-generated constructor stub
		}

		public AccountController(Account_Service accountService) {
			super();
			this.accountService = accountService;
		}
		
		//Create
		@PostMapping("/api/account/add")
		public ResponseEntity<String> saveAccount(@RequestBody Account account){
	        // Check for user in the database, should not be existing.
			   Optional<Account> userOptional = accountService.findByUsername(account.getUsername());
		        if (!userOptional.isPresent()) {
		        	accountService.saveAccount(account);
	    			return ResponseEntity.ok("Save Successful");
		        }

	        	return ResponseEntity.status(401).body("Unauthorized"); //Throw Exception
		}
		//Read All
		@GetMapping("/api/account/all")
		public List<Account> getAllAccount(){
			return accountService.getAllAccounts();
		}
		//Read by id
		@GetMapping("/api/account/{id}")
		public ResponseEntity<Account> getAccountById(@PathVariable("id") long accountid){
			return new ResponseEntity<Account>(accountService.getAccountById(accountid), HttpStatus.OK);
		}
		//Update
		@PostMapping("/api/account/update")
		public ResponseEntity<Account> updateAccount(@RequestBody Account account){
			return new ResponseEntity<Account>(accountService.updateAccount(account), HttpStatus.OK);
		}
		//Delete
		@PostMapping("/api/account/delete")
		public ResponseEntity<String> deleteAccount(@RequestBody Account account){
			accountService.deleteAccount(account);
			return new ResponseEntity<String>("Account deleted", HttpStatus.OK);
		}
	    @PostMapping("/api/account/login")
	    public ResponseEntity<String> login(@RequestBody Account account) {
	        // Check for user in the database
	        Optional<Account> userOptional = accountService.findByUsername(account.getUsername());

	        if (userOptional.isPresent()) {
	            Account user = userOptional.get();
	            if (user.getPassword().equals(account.getPassword())) {
	                return ResponseEntity.ok("Login successful");
	            }
	        }

	        return ResponseEntity.status(401).body("Unauthorized"); //Throw Exception
	    }
}
