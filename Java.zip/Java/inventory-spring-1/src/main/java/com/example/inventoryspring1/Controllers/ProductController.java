package com.example.inventoryspring1.Controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventoryspring1.Models.Product;
import com.example.inventoryspring1.Service.Product_Service;

@RestController
public class ProductController {

	@Autowired
	private Product_Service productService;

	public ProductController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductController(Product_Service productService) {
		super();
		this.productService = productService;
	}
	//Create
	@PostMapping("/api/product/add")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product){
		return new ResponseEntity<Product>(productService.saveProduct(product), HttpStatus.CREATED);
	}
	//Read All
	@GetMapping("/api/product/all")
	public List<Product> getAllCategories(){
		return productService.getAllProducts();
	}
	//Read by id
	@GetMapping("/api/product/{id}")
	public ResponseEntity<Product> getProductById(@PathVariable("id") long prodid){
		return new ResponseEntity<Product>(productService.getProductById(prodid), HttpStatus.OK);
		
	}
	//Update
	@PostMapping("/api/product/update")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product){
		return new ResponseEntity<Product>(productService.updateProduct(product), HttpStatus.OK);
	}
	//Delete
	@PostMapping("/api/product/delete")
	public ResponseEntity<String> deleteAccount(@RequestBody Product product){
		productService.deleteProduct(product);
		return new ResponseEntity<String>("Product deleted", HttpStatus.OK);
	}
	
}
