package com.example.inventoryspring1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventoryspring1.Models.Product;

public interface Product_Repo extends JpaRepository<Product, Long> {

}
