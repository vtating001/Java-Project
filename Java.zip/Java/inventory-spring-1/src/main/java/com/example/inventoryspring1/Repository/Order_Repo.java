package com.example.inventoryspring1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventoryspring1.Models.Order;

public interface Order_Repo extends JpaRepository<Order, Long>{

}
