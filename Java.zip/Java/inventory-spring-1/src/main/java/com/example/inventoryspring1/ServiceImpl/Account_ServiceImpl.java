package com.example.inventoryspring1.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.inventoryspring1.Models.Account;
import com.example.inventoryspring1.Repository.Account_Repo;
import com.example.inventoryspring1.Service.Account_Service;

@Service
public class Account_ServiceImpl implements Account_Service{

	@Autowired
	private Account_Repo accountRepo;

	public Account_ServiceImpl(Account_Repo loginRepo) {
		super();
		this.accountRepo = loginRepo;
	}

	@Override
	public Account saveAccount(Account account) {
		return accountRepo.save(account);
	}
	@Override
	public List<Account> getAllAccounts() {
		return accountRepo.findAll();
	}

	@Override
	public Account getAccountById(long id) {
		// lambda expression
		return accountRepo.findById(id).orElseThrow(
				()->new ResourceNotFoundException("Account", "ID", id)
				);
	}
	
	@Override
	public Account updateAccount(Account account) {
		// check if exists = update
		// if not exists = create
		Account existingAcc = accountRepo.findById(account.getId()).orElseThrow(
				()->new ResourceNotFoundException("Account", "ID", account.getId())
				);
		
		existingAcc.setFirstName(account.getFirstName());
		existingAcc.setLastName(account.getLastName());
		existingAcc.setUsername(account.getUsername());
		existingAcc.setPassword(account.getPassword());
		existingAcc.setUpdatedBy(account.getUpdatedBy());
		
		// save to database
		accountRepo.save(existingAcc);
		return existingAcc;
	}

	@Override
	public void deleteAccount(Account account) {
		accountRepo.findById(account.getId()).orElseThrow(
				()->new ResourceNotFoundException("Account", "ID", account.getId())
				);
		accountRepo.deleteById(account.getId());
	}
	
	public Optional<Account> findByUsername(String username) {
	    return accountRepo.findByUsername(username);
	}
	
}
