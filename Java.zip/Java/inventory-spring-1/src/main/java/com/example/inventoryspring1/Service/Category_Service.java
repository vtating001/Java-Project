package com.example.inventoryspring1.Service;

import java.util.List;

import com.example.inventoryspring1.Models.Category;

public interface Category_Service {

	Category saveCategory(Category category);

	List<Category> getAllCategories();

	Category getCategoryById(long id);

	Category updateCategory(Category category);

	void deleteCategory(Category category);

}