package com.example.inventoryspring1.ServiceImpl;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.inventoryspring1.Models.Customer;
import com.example.inventoryspring1.Repository.Customer_Repo;
import com.example.inventoryspring1.Service.Customer_Service;

@Service
public class Customer_ServiceImpl implements Customer_Service {

	private Customer_Repo customerRepo;

	public Customer_ServiceImpl(Customer_Repo customerRepo) {
		super();
		this.customerRepo = customerRepo;
	}
	@Override
	public Customer saveCustomer(Customer customer) {
		return customerRepo.save(customer);
	}
	@Override
	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}
	@Override
	public Customer getCustomerById(long id) {
		return  customerRepo.findById(id).orElseThrow(
				()->new ResourceNotFoundException("Customer", "ID", id)
				);
	}
	@Override
	public Customer updateCustomer(Customer customer) {
		Customer existingCust = customerRepo.findById(customer.getId()).orElseThrow(
				()->new ResourceNotFoundException("Customer", "ID", customer.getId())
				);
		
		existingCust.setName(customer.getName());
		existingCust.setMobile(customer.getMobile());
		existingCust.setEmail(customer.getEmail());
		existingCust.setUpdatedBy(customer.getUpdatedBy());
		
		// save to database
		customerRepo.save(existingCust);
		return existingCust;
	}
	
}
