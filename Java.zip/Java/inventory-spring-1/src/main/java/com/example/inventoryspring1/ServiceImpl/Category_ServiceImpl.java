package com.example.inventoryspring1.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.inventoryspring1.Models.Category;
import com.example.inventoryspring1.Repository.Category_Repo;
import com.example.inventoryspring1.Service.Category_Service;

@Service
public class Category_ServiceImpl implements Category_Service {

	private Category_Repo categoryRepo;

	public Category_ServiceImpl(Category_Repo categoryRepo) {
		super();
		this.categoryRepo = categoryRepo;
	}
	@Override
	public Category saveCategory(Category category) {
		return categoryRepo.save(category);
	}
	@Override
	public List<Category> getAllCategories() {
		return categoryRepo.findAll();
	}

	@Override
	public Category getCategoryById(long id) {
		// lambda expression
		return categoryRepo.findById(id).orElseThrow(
				()->new ResourceNotFoundException("Category", "ID", id)
				);
	}
	
	@Override
	public Category updateCategory(Category category) {
		// check if exists = update
		// if not exists = create
		Category existingCat = categoryRepo.findById(category.getId()).orElseThrow(
				()->new ResourceNotFoundException("Category", "ID", category.getId())
				);
		
		existingCat.setName(category.getName());
		existingCat.setUpdatedBy(category.getUpdatedBy());
		
		// save to database
		categoryRepo.save(existingCat);
		return existingCat;
	}

	@Override
	public void deleteCategory(Category category) {
		categoryRepo.findById(category.getId()).orElseThrow(
				()->new ResourceNotFoundException("Category", "ID", category.getId())
				);
		categoryRepo.deleteById(category.getId());
	}
}
