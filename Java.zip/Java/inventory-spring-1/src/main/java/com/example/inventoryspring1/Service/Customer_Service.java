package com.example.inventoryspring1.Service;

import java.util.List;

import com.example.inventoryspring1.Models.Customer;

public interface Customer_Service {
	
	Customer saveCustomer(Customer customer);

	List<Customer> getAllCustomers();

	Customer getCustomerById(long id);

	Customer updateCustomer(Customer customer);
}
