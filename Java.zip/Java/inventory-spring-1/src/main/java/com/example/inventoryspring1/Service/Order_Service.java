package com.example.inventoryspring1.Service;

import java.util.List;

import com.example.inventoryspring1.Models.Order;

public interface Order_Service {

	List<Order> saveOrder(List<Order> order);
}
