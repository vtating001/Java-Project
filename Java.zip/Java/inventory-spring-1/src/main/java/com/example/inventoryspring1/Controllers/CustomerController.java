package com.example.inventoryspring1.Controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventoryspring1.Models.Customer;
import com.example.inventoryspring1.Service.Customer_Service;

@RestController
public class CustomerController {

	@Autowired
	private Customer_Service customerService;

	public CustomerController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerController(Customer_Service customerService) {
		super();
		this.customerService = customerService;
	}
	
	//Create
		@PostMapping("/api/customer/add")
		public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer){
			return new ResponseEntity<Customer>(customerService.saveCustomer(customer), HttpStatus.CREATED);
		}
		//Read All
		@GetMapping("/api/customer/all")
		public List<Customer> getAllCustomers(){
			return customerService.getAllCustomers();
		}
		//Read by id
		@GetMapping("/api/customer/{id}")
		public ResponseEntity<Customer> getCustomerById(@PathVariable("id") long custid){
			return new ResponseEntity<Customer>(customerService.getCustomerById(custid), HttpStatus.OK);
			
		}
		//Update
		@PostMapping("/api/customer/update")
		public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer){
			return new ResponseEntity<Customer>(customerService.updateCustomer(customer), HttpStatus.OK);
		}
}
