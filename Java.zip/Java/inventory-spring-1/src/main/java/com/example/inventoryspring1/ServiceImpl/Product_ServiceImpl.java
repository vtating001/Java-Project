package com.example.inventoryspring1.ServiceImpl;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.inventoryspring1.Models.Product;
import com.example.inventoryspring1.Repository.Product_Repo;
import com.example.inventoryspring1.Service.Product_Service;

@Service
public class Product_ServiceImpl implements Product_Service {

		private Product_Repo productRepo;

		public Product_ServiceImpl(Product_Repo productRepo) {
			super();
			this.productRepo = productRepo;
		}
		
		@Override
		public Product saveProduct(Product product) {
			return productRepo.save(product);
		}
		@Override
		public List<Product> getAllProducts() {
			return productRepo.findAll();
		}
		@Override
		public Product getProductById(long id) {
			return  productRepo.findById(id).orElseThrow(
					()->new ResourceNotFoundException("Product", "ID", id)
					);
		}
		@Override
		public Product updateProduct(Product product) {
			Product existingProd = productRepo.findById(product.getId()).orElseThrow(
					()->new ResourceNotFoundException("Product", "ID", product.getId())
					);
			
			existingProd.setName(product.getName());
			existingProd.setPrice(product.getPrice());
			existingProd.setQuantity(product.getQuantity());
			existingProd.setDescription(product.getDescription());
			existingProd.setCategory(product.getCategory());
			existingProd.setUpdatedBy(product.getUpdatedBy());
			
			
			// save to database
			productRepo.save(existingProd);
			return existingProd;
		}
		@Override
		public void deleteProduct(Product product) {
			productRepo.findById(product.getId()).orElseThrow(
					()->new ResourceNotFoundException("Product", "ID", product.getId())
					);
			productRepo.deleteById(product.getId());
		}
}
