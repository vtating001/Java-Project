package com.example.inventoryspring1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.inventoryspring1.Models.Customer;

public interface Customer_Repo extends JpaRepository<Customer, Long>{

}
