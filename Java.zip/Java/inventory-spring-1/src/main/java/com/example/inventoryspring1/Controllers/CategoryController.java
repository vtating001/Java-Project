package com.example.inventoryspring1.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.inventoryspring1.Models.Category;
import com.example.inventoryspring1.Service.Category_Service;

@RestController
public class CategoryController {
	
		@Autowired
		private Category_Service categoryService;

		
		public CategoryController() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public CategoryController(Category_Service categoryService) {
			super();
			this.categoryService = categoryService;
		}
		
		//Create
		@PostMapping("/api/category/add")
		public ResponseEntity<Category> saveCategory(@RequestBody Category category){
			return new ResponseEntity<Category>(categoryService.saveCategory(category), HttpStatus.CREATED);
		}
		//Read All
		@GetMapping("/api/category/all")
		public List<Category> getAllCategories(){
			return categoryService.getAllCategories();
		}
		//Read by id
		@GetMapping("/api/category/{id}")
		public ResponseEntity<Category> getCategoryById(@PathVariable("id") long catid){
			return new ResponseEntity<Category>(categoryService.getCategoryById(catid), HttpStatus.OK);
			
		}
		//Update
		@PostMapping("/api/category/update")
		public ResponseEntity<Category> updateCategory(@RequestBody Category category){
			return new ResponseEntity<Category>(categoryService.updateCategory(category), HttpStatus.OK);
		}
		//Delete
		@PostMapping("/api/category/delete")
		public ResponseEntity<String> deleteAccount(@RequestBody Category category){
			categoryService.deleteCategory(category);
			return new ResponseEntity<String>("Category deleted", HttpStatus.OK);
		}
}
