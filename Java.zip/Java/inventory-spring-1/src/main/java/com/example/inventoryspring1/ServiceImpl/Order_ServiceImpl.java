package com.example.inventoryspring1.ServiceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.inventoryspring1.Models.Order;
import com.example.inventoryspring1.Repository.Order_Repo;
import com.example.inventoryspring1.Service.Order_Service;

@Service
public class Order_ServiceImpl implements Order_Service{

	private Order_Repo orderRepo;

	public Order_ServiceImpl(Order_Repo orderRepo) {
		super();
		this.orderRepo = orderRepo;
	}
	
	@Override
	public List<Order> saveOrder(List<Order> order) {
		return orderRepo.saveAll(order);
	}
}
