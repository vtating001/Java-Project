package com.example.inventoryspring1.Service;

import java.util.List;

import com.example.inventoryspring1.Models.Product;

public interface Product_Service {
	
	Product saveProduct(Product product);

	List<Product> getAllProducts();

	Product getProductById(long id);

	Product updateProduct(Product product);
	void deleteProduct(Product product);
}
