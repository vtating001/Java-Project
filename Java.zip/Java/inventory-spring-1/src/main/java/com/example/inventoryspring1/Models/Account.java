package com.example.inventoryspring1.Models;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_accounts")
public class Account {
	
	// define primary key, auto-increment
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;
		
		// define other columns
		@Column(name="first_name")
		private String firstName;
		
		@Column(name="last_name")
		private String lastName;

		@Column(name="username", unique = true)
		private String username;

		@Column(name="password")
		private String password;

		@Column(name="created_at")
		@CreationTimestamp
		private LocalDateTime timestamp;
		
		@Column(name="updated_on")
		@UpdateTimestamp
		private LocalDateTime updatedOn;
		
		@Column(name="updated_by")
		private String updatedBy;
		
		public Account() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Account(long id, String firstName, String lastName, String username, String password,
				LocalDateTime timestamp, LocalDateTime updatedOn, String updatedBy) {
			super();
			this.id = id;
			this.firstName = firstName;
			this.lastName = lastName;
			this.username = username;
			this.password = password;
			this.timestamp = timestamp;
			this.updatedOn = updatedOn;
			this.updatedBy = updatedBy;
		}

		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public LocalDateTime getTimestamp() {
			return timestamp;
		}

		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}

		public LocalDateTime getUpdatedOn() {
			return updatedOn;
		}

		public void setUpdatedOn(LocalDateTime updatedOn) {
			this.updatedOn = updatedOn;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

}
