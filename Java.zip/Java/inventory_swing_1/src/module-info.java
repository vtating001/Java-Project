/**
 * 
 */
/**
 * 
 */
module inventory_swing_1 {
	requires java.desktop;
	requires org.json;
}