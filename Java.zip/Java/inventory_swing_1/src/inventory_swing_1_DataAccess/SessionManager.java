package inventory_swing_1_DataAccess;

public class SessionManager {
	private static SessionManager instance;
	private String Username;
	private SessionManager() {

	}
	public static synchronized SessionManager getInstance() {
		if(instance == null) {
			instance = new SessionManager();
		}
		return instance;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		this.Username = username;
	}
	public void clearSession() {
		this.Username = null;
	}
	
}
