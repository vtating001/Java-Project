package inventory_swing_1_DataAccess;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

public class ApiClient {

    public static String sendRequest(String endpoint, String method, String jsonInputString) throws Exception {
        // Create URI from the endpoint string
        URI uri = new URI(endpoint);
        // Convert URI to URL
        URL url = uri.toURL();
        
        // Open connection
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(method);
        connection.setRequestProperty("Content-Type", "application/json; utf-8");
        connection.setRequestProperty("Accept", "application/json");
        connection.setDoOutput(true);

        // Write the request body if provided
        if (jsonInputString != null) {
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
        }

        // Read the response
        int code = connection.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(
                connection.getInputStream(), "utf-8"));
        StringBuilder response = new StringBuilder();
        String responseLine;
        while ((responseLine = br.readLine()) != null) {
            response.append(responseLine.trim());
        }

        return code + ":" + response.toString();
    }
}
