package inventory_swing_1;

import javax.swing.*;

import inventory_swing_1_DataAccess.SessionManager;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame {

	private static final long serialVersionUID = 1L;

	public Home() {
        // Set the title and default close operation
        setTitle("Inventory Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        // Set the frame to be maximized
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        // Create a menu bar
        JMenuBar menuBar = new JMenuBar();
        
        // Create the "Account Management" menu
        JMenu mainMenu = new JMenu("Menu");
        
        // Create menu items
        JMenuItem manageAccountsItem = new JMenuItem("Account Management");
        JMenuItem manageCategoryItem = new JMenuItem("Categories");
        JMenuItem manageCustomerItem = new JMenuItem("Customers");
        JMenuItem manageProductItem = new JMenuItem("Products");
        JMenuItem manageOrdersItem = new JMenuItem("Orders");
        JMenuItem logOutItem = new JMenuItem("Logout");

        // Add action listeners to menu items (optional)
        manageAccountsItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the main application window
                SwingUtilities.invokeLater(() -> {
                    JFrame UMFrame = new UserManagementFrame();
                    UMFrame.setVisible(true);
                });
            }
        });
        manageCategoryItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the main application window
                SwingUtilities.invokeLater(() -> {
                    JFrame CFrame = new CategoriesFrame();
                    CFrame.setVisible(true);
                });
            }
        });
        manageCustomerItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the main application window
                SwingUtilities.invokeLater(() -> {
                    JFrame PFrame = new CustomersFrame();
                    PFrame.setVisible(true);
                });
            }
        });
        manageProductItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the main application window
                SwingUtilities.invokeLater(() -> {
                    JFrame ProFrame = new ProductsFrame();
                    ProFrame.setVisible(true);
                });
            }
        });
        manageOrdersItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the main application window
                SwingUtilities.invokeLater(() -> {
                    JFrame OFrame = new OrderFrame();
                    OFrame.setVisible(true);
                });
            }
        });
        logOutItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	SessionManager.getInstance().clearSession();
               dispose();
               // Open the main application window
               SwingUtilities.invokeLater(() -> {
                   JFrame mainFrame = new Login();
                   mainFrame.setVisible(true);
               });
            }
        });

        // Add menu items to the "Account Management" menu
        mainMenu.add(manageAccountsItem);
        mainMenu.add(manageCategoryItem);
        mainMenu.add(manageCustomerItem);
        mainMenu.add(manageProductItem);
        mainMenu.add(manageOrdersItem);
        mainMenu.add(logOutItem);

        // Add the "Account Management" menu to the menu bar
        menuBar.add(mainMenu);

        // Set the menu bar to the frame
        setJMenuBar(menuBar);
    }

}
