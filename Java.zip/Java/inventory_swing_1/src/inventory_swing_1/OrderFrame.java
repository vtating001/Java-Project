package inventory_swing_1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import org.json.JSONArray;
import org.json.JSONObject;
import inventory_swing_1_DataAccess.ApiClient;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class OrderFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JComboBox<Customer> customerComboBox;
    private JComboBox<Product> productComboBox;
    private JButton addButton;
    private JButton finalizeButton;
    private JTable cartTable;
    private DefaultTableModel cartTableModel;
    private JTextArea outputArea;
    private JTextField quantityField;

    private List<Customer> customers = new ArrayList<>();
    private List<Product> products = new ArrayList<>();

    public OrderFrame() {
        // Set up the frame
        setTitle("Manage Order");
        setSize(600, 432);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(null);

        // Initialize GUI components
        initializeComponents();

        // Fetch customers and products from API
        fetchCustomersFromApiToComboBox();
        fetchProductsFromApiToComboBox();
    }

    private void initializeComponents() {
        // Customer selection
        JLabel customerLabel = new JLabel("Select Customer:");
        customerLabel.setBounds(10, 10, 150, 25);
        getContentPane().add(customerLabel);

        customerComboBox = new JComboBox<>();
        customerComboBox.setBounds(160, 10, 200, 25);
        getContentPane().add(customerComboBox);

        // Product selection
        JLabel productLabel = new JLabel("Select Product:");
        productLabel.setBounds(10, 50, 150, 25);
        getContentPane().add(productLabel);

        productComboBox = new JComboBox<>();
        productComboBox.setBounds(160, 50, 200, 25);
        getContentPane().add(productComboBox);

        // Quantity input
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setBounds(10, 90, 150, 25);
        getContentPane().add(quantityLabel);

        quantityField = new JTextField("1"); // Default quantity
        quantityField.setBounds(160, 90, 50, 25);
        getContentPane().add(quantityField);

        // Add to Cart button
        addButton = new JButton("Add to Cart");
        addButton.setBounds(220, 90, 150, 25);
        getContentPane().add(addButton);

        // Finalize Order button
        finalizeButton = new JButton("Finalize Order");
        finalizeButton.setBounds(10, 130, 150, 25);
        getContentPane().add(finalizeButton);

        // Cart Table
        String[] columnNames = {"Customer", "Product", "Quantity", "Price", "Total"};
        cartTableModel = new DefaultTableModel(columnNames, 0);
        cartTable = new JTable(cartTableModel);
        JScrollPane tableScrollPane = new JScrollPane(cartTable);
        tableScrollPane.setBounds(10, 170, 560, 150);
        getContentPane().add(tableScrollPane);

        // Output area
        outputArea = new JTextArea();
        outputArea.setBounds(10, 330, 560, 60);
        outputArea.setEditable(false);
        getContentPane().add(outputArea);
        
        JButton btnReset = new JButton("Reset Cart");
        btnReset.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		ResetInputs();
        	}
        });
        btnReset.setBounds(170, 132, 85, 21);
        getContentPane().add(btnReset);

        // Add action listeners
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Product selectedProduct = (Product) productComboBox.getSelectedItem();
                Customer selectedCustomer = (Customer) customerComboBox.getSelectedItem();

                if (selectedProduct != null && selectedCustomer != null) {
                    String customerName = selectedCustomer.getName() + " - " + selectedCustomer.getId();
                    String productName = selectedProduct.getName() + " - " + selectedProduct.getId();
                    String productPrice = selectedProduct.getPrice();
                    String quantityText = quantityField.getText();
                    int quantity = 1; // Default to 1 if not valid input
                    double total = Double.parseDouble(productPrice) * Double.parseDouble(quantityText);

                    // Validate and parse quantity
                    try {
                        quantity = Integer.parseInt(quantityText);
                        if (quantity < 1) {
                            quantity = 1; // Set minimum quantity
                        }
                    } catch (NumberFormatException ex) {
                        outputArea.append("Invalid quantity. Defaulting to 1.\n");
                    }

                    // Check if the item already exists in the cart
                    boolean itemExists = false;
                    for (int i = 0; i < cartTableModel.getRowCount(); i++) {
                        String existingCustomerName = (String) cartTableModel.getValueAt(i, 0);
                        String existingProductName = (String) cartTableModel.getValueAt(i, 1);
                        if (existingCustomerName.equals(customerName) && existingProductName.equals(productName)) {
                            // Update quantity and total for the existing item
                            int existingQuantity = (int) cartTableModel.getValueAt(i, 2);
                            int newQuantity = existingQuantity + quantity;
                            double newTotal = Double.parseDouble(productPrice) * newQuantity;

                            cartTableModel.setValueAt(newQuantity, i, 2);
                            cartTableModel.setValueAt(String.format("%.2f", newTotal), i, 4);
                            outputArea.append("Updated quantity and total for: " + productName + "\n");

                            itemExists = true;
                            break;
                        }
                    }

                    // Add new item if it does not exist
                    if (!itemExists) {
                        cartTableModel.addRow(new Object[]{customerName, productName, quantity, productPrice, total});
                        outputArea.append("Added to cart: " + productName + " - Quantity: " + quantity + ", Price: " + productPrice + "\n");
                    }

                    // Disable customer combo box if cart is not empty
                    updateCustomerComboBoxState();
                }
            }
        });


        finalizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	if(cartTableModel.getRowCount() != 0) {
            		 int result = JOptionPane.showConfirmDialog(null, 
          				   "Do you want to proceed to finalize this order?",
          				   "Confirmation",
          				   JOptionPane.YES_NO_OPTION,
          				   JOptionPane.QUESTION_MESSAGE);
                  
            		 if(result == JOptionPane.YES_OPTION) {

                 		String uid = generateRandomID();
                          // Build the JSON request body
                          JSONArray orderItems = new JSONArray();

                          for (int i = 0; i < cartTableModel.getRowCount(); i++) {
                              String custValue = (String) cartTableModel.getValueAt(i, 0);
                              String[] customerSplit = custValue.split(" - ");
                              String prodValue = (String) cartTableModel.getValueAt(i, 1);
                              String[] prodSplit = prodValue.split(" - ");
                              
                              JSONObject item = new JSONObject();

                              // Extract data from cart table
                              String customerId = customerSplit[1];
                              String productId = prodSplit[1]; // Assuming ID is the first part
                              int quantity = (int) cartTableModel.getValueAt(i, 2);
//                              double price = (double) cartTableModel.getValueAt(i, 3);

                              // Create product JSON
                              JSONObject productJson = new JSONObject();
                              productJson.put("id", productId);

                              // Create customer JSON
                              JSONObject customerJson = new JSONObject();
                              customerJson.put("id", customerId);

                              // Create order item JSON
                              item.put("customer", customerJson);
                              item.put("product", productJson);
                              item.put("quantity", quantity);
                              item.put("orderID", uid); // Use method to generate a random order ID
                              orderItems.put(item);
                          }

                          // Convert the JSON array to a string
                          String requestBody = orderItems.toString();

                        // Send the request to API
                          String apiEndpoint = "http://localhost:8080/api/order/add";

                          try {
                              String response = ApiClient.sendRequest(apiEndpoint, "POST", requestBody);
                              if (response.startsWith("200:") || response.startsWith("201:")) {
                              	JOptionPane.showMessageDialog(
                      					null, 
                      					"Order finalized successfully!", 
                      					"Success", 
                      					JOptionPane.INFORMATION_MESSAGE);
                                  outputArea.append("Order finalized successfully!\n");
                              } else {
                                  throw new IOException("Failed to finalize order. HTTP response code: " + response);
                              }
                          } catch (Exception ex) {
                          	JOptionPane.showMessageDialog(
                      				null, 
                      				"Error finalizing order: " + ex.getMessage() + "\n", 
                      				"Error", 
                      				JOptionPane.INFORMATION_MESSAGE);
                          }

                          
                          // Reset input fields
                          ResetInputs();
            			 
            		 }
            		
            		
            	}
            	else {
            		JOptionPane.showMessageDialog(
             				null, 
             				"Cannot process your request. Please try again.", 
             				"Error", 
             				JOptionPane.INFORMATION_MESSAGE);
            	}
               
            }
        });
    }
    private String generateRandomID() {
        return UUID.randomUUID().toString();
    }
    private void ResetInputs() {
        cartTableModel.setRowCount(0);
        updateCustomerComboBoxState();
        quantityField.setText("");
    }
    private boolean isCartEmpty() {
        return cartTableModel.getRowCount() == 0;
    }

    private void updateCustomerComboBoxState() {
        customerComboBox.setEnabled(isCartEmpty());
    }

    private void fetchCustomersFromApiToComboBox() {
        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/customer/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
                response = response.substring(4);
            } else {
                // Handle non-200 responses
                throw new IOException("Failed to fetch data. HTTP response code: " + response);
            }

            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the customer list
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String id = jsonObject.optString("id");
                String name = jsonObject.optString("name");

                customers.add(new Customer(id, name));
            }

            // Populate JComboBox
            DefaultComboBoxModel<Customer> model = new DefaultComboBoxModel<>(customers.toArray(new Customer[0]));
            customerComboBox.setModel(model);

        } catch (Exception e) {
            System.out.println("API error: " + e.getMessage());
        }
    }

    private void fetchProductsFromApiToComboBox() {
        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/product/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
                response = response.substring(4);
            } else {
                // Handle non-200 responses
                throw new IOException("Failed to fetch data. HTTP response code: " + response);
            }

            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the product list
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String id = jsonObject.optString("id");
                String name = jsonObject.optString("name");
                String price = jsonObject.optString("price");

                products.add(new Product(id, name, price));
            }

            // Populate JComboBox
            DefaultComboBoxModel<Product> model = new DefaultComboBoxModel<>(products.toArray(new Product[0]));
            productComboBox.setModel(model);

        } catch (Exception e) {
            System.out.println("API error: " + e.getMessage());
        }
    }

    public static class Customer {
        private String id;
        private String name;

        public Customer(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return name; // This is what will be displayed in the JComboBox
        }
    }

    public static class Product {
        private String id;
        private String name;
        private String price;

        public Product(String id, String name, String price) {
            this.id = id;
            this.name = name;
            this.price = price;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        @Override
        public String toString() {
            return name + " - " + price; // This is what will be displayed in the JComboBox
        }
    }

    public static void main(String[] args) {
        // Run the frame
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new OrderFrame().setVisible(true);
            }
        });
    }
}
