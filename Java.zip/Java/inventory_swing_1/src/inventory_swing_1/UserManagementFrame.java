package inventory_swing_1;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import org.json.JSONArray;
import org.json.JSONObject;
import inventory_swing_1_DataAccess.ApiClient;
import inventory_swing_1_DataAccess.SessionManager;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class UserManagementFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private String sessionUserName = SessionManager.getInstance().getUsername();
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JTextField firstnameField;
    private JTextField idField;
    private JTextField lastnameField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel messageLabel;
    private JButton btnCreate;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;

    public UserManagementFrame() {
        setTitle("User Management");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initializeUI();
        setSizeAndPosition();
        fetchDataFromApi();
    }

    private void initializeUI() {
        getContentPane().setLayout(new BorderLayout());

        // Create panel for form and buttons
        JPanel formPanel = new JPanel();
        formPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
        GridBagLayout gbl_formPanel = new GridBagLayout();
        gbl_formPanel.columnWeights = new double[]{1.0, 0.0};
        formPanel.setLayout(gbl_formPanel);
        
        JLabel IDLabel = new JLabel("ID");
        GridBagConstraints gbc_IDLabel = new GridBagConstraints();
        gbc_IDLabel.insets = new Insets(0, 0, 5, 5);
        gbc_IDLabel.gridx = 0;
        gbc_IDLabel.gridy = 0;
        formPanel.add(IDLabel, gbc_IDLabel);

        // Add components to formPanel with different constraints

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;

        // Create the table
        String[] columnNames = {"ID", "First Name", "Last Name", "Username", "Password", "Created At", "Updated By", "Updated At"};
        tableModel = new DefaultTableModel(columnNames, 0);
        userTable = new JTable(tableModel);

        // Create a scroll pane for the table
        JScrollPane tableScrollPane = new JScrollPane(userTable);

        // Add components to the frame
        getContentPane().add(formPanel, BorderLayout.WEST);
        
        idField = new JTextField();
        idField.setEditable(false);
        GridBagConstraints gbc_idField = new GridBagConstraints();
        gbc_idField.insets = new Insets(0, 0, 5, 0);
        gbc_idField.fill = GridBagConstraints.HORIZONTAL;
        gbc_idField.gridx = 1;
        gbc_idField.gridy = 0;
        formPanel.add(idField, gbc_idField);
        idField.setColumns(10);
        
        JLabel firstNameLabel = new JLabel("First Name:");
        GridBagConstraints gbc_firstNameLabel = new GridBagConstraints();
        gbc_firstNameLabel.insets = new Insets(0, 0, 5, 5);
        gbc_firstNameLabel.anchor = GridBagConstraints.EAST;
        gbc_firstNameLabel.gridx = 0;
        gbc_firstNameLabel.gridy = 1;
        formPanel.add(firstNameLabel, gbc_firstNameLabel);
        
        firstnameField = new JTextField();
        GridBagConstraints gbc_firstnameField = new GridBagConstraints();
        gbc_firstnameField.insets = new Insets(0, 0, 5, 0);
        gbc_firstnameField.fill = GridBagConstraints.HORIZONTAL;
        gbc_firstnameField.gridx = 1;
        gbc_firstnameField.gridy = 1;
        formPanel.add(firstnameField, gbc_firstnameField);
        firstnameField.setColumns(10);
        
        JLabel lastNameLabrel = new JLabel("Last Name:");
        GridBagConstraints gbc_lastNameLabrel = new GridBagConstraints();
        gbc_lastNameLabrel.insets = new Insets(0, 0, 5, 5);
        gbc_lastNameLabrel.anchor = GridBagConstraints.EAST;
        gbc_lastNameLabrel.gridx = 0;
        gbc_lastNameLabrel.gridy = 2;
        formPanel.add(lastNameLabrel, gbc_lastNameLabrel);
        
        lastnameField = new JTextField();
        GridBagConstraints gbc_lastNameField = new GridBagConstraints();
        gbc_lastNameField.insets = new Insets(0, 0, 5, 0);
        gbc_lastNameField.fill = GridBagConstraints.HORIZONTAL;
        gbc_lastNameField.gridx = 1;
        gbc_lastNameField.gridy = 2;
        formPanel.add(lastnameField, gbc_lastNameField);
        lastnameField.setColumns(10);
        
        JLabel userNameLabel = new JLabel("Username:");
        GridBagConstraints gbc_userNameLabel = new GridBagConstraints();
        gbc_userNameLabel.anchor = GridBagConstraints.EAST;
        gbc_userNameLabel.insets = new Insets(0, 0, 5, 5);
        gbc_userNameLabel.gridx = 0;
        gbc_userNameLabel.gridy = 3;
        formPanel.add(userNameLabel, gbc_userNameLabel);
        
        usernameField = new JTextField();
        GridBagConstraints gbc_usernameField = new GridBagConstraints();
        gbc_usernameField.insets = new Insets(0, 0, 5, 0);
        gbc_usernameField.fill = GridBagConstraints.HORIZONTAL;
        gbc_usernameField.gridx = 1;
        gbc_usernameField.gridy = 3;
        formPanel.add(usernameField, gbc_usernameField);
        usernameField.setColumns(10);
        
        JLabel passwordLabel = new JLabel("Password:");
        GridBagConstraints gbc_passwordLabel = new GridBagConstraints();
        gbc_passwordLabel.anchor = GridBagConstraints.EAST;
        gbc_passwordLabel.insets = new Insets(0, 0, 5, 5);
        gbc_passwordLabel.gridx = 0;
        gbc_passwordLabel.gridy = 4;
        formPanel.add(passwordLabel, gbc_passwordLabel);
        
        passwordField = new JPasswordField();
        GridBagConstraints gbc_passwordField = new GridBagConstraints();
        gbc_passwordField.insets = new Insets(0, 0, 5, 0);
        gbc_passwordField.fill = GridBagConstraints.HORIZONTAL;
        gbc_passwordField.gridx = 1;
        gbc_passwordField.gridy = 4;
        formPanel.add(passwordField, gbc_passwordField);
        
        btnCreate = new JButton("Create");
        GridBagConstraints gbc_btnCreate = new GridBagConstraints();
        gbc_btnCreate.anchor = GridBagConstraints.WEST;
        gbc_btnCreate.insets = new Insets(0, 0, 5, 0);
        gbc_btnCreate.gridx = 1;
        gbc_btnCreate.gridy = 5;
        formPanel.add(btnCreate, gbc_btnCreate);
        
        btnUpdate = new JButton("Update");
        GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
        gbc_btnUpdate.insets = new Insets(0, 0, 5, 0);
        gbc_btnUpdate.anchor = GridBagConstraints.WEST;
        gbc_btnUpdate.gridx = 1;
        gbc_btnUpdate.gridy = 6;
        formPanel.add(btnUpdate, gbc_btnUpdate);
        
        btnDelete = new JButton("Delete");
        GridBagConstraints gbc_btnDelete = new GridBagConstraints();
        gbc_btnDelete.insets = new Insets(0, 0, 5, 0);
        gbc_btnDelete.anchor = GridBagConstraints.WEST;
        gbc_btnDelete.gridx = 1;
        gbc_btnDelete.gridy = 7;
        formPanel.add(btnDelete, gbc_btnDelete);
        
        btnClear = new JButton("Clear");
        btnClear.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		clearInputs();
        	}
        });
        
        GridBagConstraints gbc_btnClear = new GridBagConstraints();
        gbc_btnClear.anchor = GridBagConstraints.WEST;
        gbc_btnClear.insets = new Insets(0, 0, 5, 0);
        gbc_btnClear.gridx = 1;
        gbc_btnClear.gridy = 8;
        formPanel.add(btnClear, gbc_btnClear);
        
        messageLabel = new JLabel("");
        GridBagConstraints gbc_messageLabel = new GridBagConstraints();
        gbc_messageLabel.insets = new Insets(0, 0, 0, 5);
        gbc_messageLabel.gridx = 0;
        gbc_messageLabel.gridy = 9;
        formPanel.add(messageLabel, gbc_messageLabel);
        getContentPane().add(tableScrollPane, BorderLayout.CENTER);

//        // Add action listeners
        btnCreate.addActionListener(e -> handleAction("create"));
        btnUpdate.addActionListener(e -> handleAction("update"));
        btnDelete.addActionListener(e -> handleAction("delete"));

//         Add a row selection listener
        userTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Get the selected row
                int selectedRow = userTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // Get data from the selected row
                	idField.setText((String) userTable.getValueAt(selectedRow, 0));
                    firstnameField.setText((String) userTable.getValueAt(selectedRow, 1));
                    lastnameField.setText((String) userTable.getValueAt(selectedRow, 2));
                    usernameField.setText((String) userTable.getValueAt(selectedRow, 3));
                    passwordField.setText((String) userTable.getValueAt(selectedRow, 4));
                }
            }
        });
    }

    private void handleAction(String action) {
    	
    	String id = idField.getText();
        String firstname = firstnameField.getText();
        String lastname = lastnameField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        String endpoint = "";
        String method = "POST";
        String jsonInputString = "";
        
        //prep the action
        if (action.equals("create")) {
            endpoint = "http://localhost:8080/api/account/add";
            jsonInputString = "{ \"firstName\": \"" + firstname + "\", \"firstName\": \"" + firstname + "\", \"lastName\": \"" + lastname + "\", \"username\": \"" + username + "\", \"password\": \"" + password + "\" }";
        }
        else if (action.equals("update")) {
        	System.out.print(sessionUserName);
            endpoint = "http://localhost:8080/api/account/update";
            jsonInputString = "{\"id\": \"" + id + "\", \"firstName\": \"" + firstname + "\", \"firstName\": \"" + firstname + "\", \"lastName\": \"" + lastname + "\", \"username\": \"" + username + "\", \"password\": \"" + password + "\", \"updatedBy\": \"" + sessionUserName + "\"}";
        }
        else if (action.equals("delete")) {
            endpoint = "http://localhost:8080/api/account/delete";
            jsonInputString = "{\"id\": \"" + id + "\"}";
        } 
        else {
	        System.out.println("Unknown Action");
        }
       
        int result = JOptionPane.showConfirmDialog(null, 
				   "Do you want to proceed to " + action + " this?",
				   "Confirmation",
				   JOptionPane.YES_NO_OPTION,
				   JOptionPane.QUESTION_MESSAGE);
        
        //YES
        if(result == JOptionPane.YES_OPTION) {
        	try {
        		String response = ApiClient.sendRequest(endpoint, method, jsonInputString);
        		if (response.startsWith("200:") || response.startsWith("201:")) {
        			JOptionPane.showMessageDialog(
        					null, 
        					action.substring(0, 1).toUpperCase() + action.substring(1) + " successful", 
        					"Success", 
        					JOptionPane.INFORMATION_MESSAGE);
        			clearInputs();
        			fetchDataFromApi();
        		}
        	} catch (Exception e) {
        		JOptionPane.showMessageDialog(
        				null, 
        				"Cannot process your request. Please try again.", 
        				"Error", 
        				JOptionPane.INFORMATION_MESSAGE);
        	}
        }
    }
    
    private void fetchDataFromApi() {
        // Clear existing rows
        tableModel.setRowCount(0);

        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/account/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
            	response = response.substring(4);
            } 
            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                
                String id = jsonObject.optString("id");
                String firstname = jsonObject.optString("firstName");
                String lastname = jsonObject.optString("lastName");
                String username = jsonObject.optString("username");
                String password = jsonObject.optString("password");
                String createdAt = jsonObject.optString("timestamp");
                String updatedBy = jsonObject.optString("updatedBy");
                String updatedAt = jsonObject.optString("updatedOn");
                
                //System.out.print(id);
                // Add row to table model
                tableModel.addRow(new Object[]{id, firstname, lastname, username, password, createdAt, updatedBy, updatedAt});
            }

        } catch (Exception e) {
        	messageLabel.setText("API error: " + e.getMessage());
        }
    }

    private void setSizeAndPosition() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        int width = (int) (screenSize.width * 0.8);
        int height = (int) (screenSize.height * 0.8);

        setSize(width, height);
        setLocationRelativeTo(null);
    }
    private void clearInputs() {
    	idField.setText("");
        firstnameField.setText("");
        lastnameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserManagementFrame frame = new UserManagementFrame();
            frame.setVisible(true);
        });
    }
}
