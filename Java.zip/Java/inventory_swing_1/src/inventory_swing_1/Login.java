package inventory_swing_1;

import javax.swing.*;

import inventory_swing_1_DataAccess.ApiClient;
import inventory_swing_1_DataAccess.SessionManager;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel messageLabel;

    
	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        getContentPane().add(panel);
        placeComponents(panel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        
        passwordField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                	login();
                }
            }
        });
	}
	
    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(100, 20, 165, 25);
        panel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 50, 80, 25);
        panel.add(passwordLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(100, 50, 165, 25);
        panel.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(95, 84, 80, 25);
        panel.add(loginButton);

        messageLabel = new JLabel("");
        messageLabel.setBounds(10, 121, 300, 25);
        panel.add(messageLabel);
    }
    
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String endpoint = "http://localhost:8080/api/account/login";
        String method = "POST";
        String jsonInputString = "{\"username\": \"" + username + "\", \"password\": \"" + password + "\"}";

        try {
            String response = ApiClient.sendRequest(endpoint, method, jsonInputString);
            if (response.startsWith("200:")) {
                dispose();
                SessionManager.getInstance().clearSession();
                SessionManager.getInstance().setUsername(username);
                SwingUtilities.invokeLater(() -> {
                    JFrame mainFrame = new Home();
                    mainFrame.setVisible(true);
                });
            } else {
                messageLabel.setText("Login failed: " + response);
                messageLabel.setForeground(Color.red);
            }
        } catch (Exception e) {
            messageLabel.setText("Invalid Username and Password");
            messageLabel.setForeground(Color.red);
        }
    }

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
