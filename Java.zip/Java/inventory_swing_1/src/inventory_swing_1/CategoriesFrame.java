package inventory_swing_1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

import inventory_swing_1_DataAccess.ApiClient;
import inventory_swing_1_DataAccess.SessionManager;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class CategoriesFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private String sessionUserName = SessionManager.getInstance().getUsername();
    private JTable catTable;
    private DefaultTableModel tableModel;
    private JTextField categoryField;
    private JTextField idField;
    private JLabel messageLabel;
    private JButton btnCreate;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;

    public CategoriesFrame() {
        setTitle("Categories");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initializeUI();
        setSizeAndPosition();
        fetchDataFromApi();
    }

    private void initializeUI() {
        getContentPane().setLayout(new BorderLayout());

        // Create panel for form and buttons
        JPanel formPanel = new JPanel();
        formPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
        GridBagLayout gbl_formPanel = new GridBagLayout();
        gbl_formPanel.columnWeights = new double[]{1.0, 0.0};
        formPanel.setLayout(gbl_formPanel);
        
        JLabel IDLabel = new JLabel("ID");
        GridBagConstraints gbc_IDLabel = new GridBagConstraints();
        gbc_IDLabel.insets = new Insets(0, 0, 5, 5);
        gbc_IDLabel.gridx = 0;
        gbc_IDLabel.gridy = 0;
        formPanel.add(IDLabel, gbc_IDLabel);

        // Add components to formPanel with different constraints

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;

        // Create the table
        String[] columnNames = {"ID", "Category Name", "Created At", "Updated By", "Updated At"};
        tableModel = new DefaultTableModel(columnNames, 0);
        catTable = new JTable(tableModel);

        // Create a scroll pane for the table
        JScrollPane tableScrollPane = new JScrollPane(catTable);

        // Add components to the frame
        getContentPane().add(formPanel, BorderLayout.WEST);
        
        idField = new JTextField();
        idField.setEditable(false);
        GridBagConstraints gbc_idField = new GridBagConstraints();
        gbc_idField.insets = new Insets(0, 0, 5, 0);
        gbc_idField.fill = GridBagConstraints.HORIZONTAL;
        gbc_idField.gridx = 1;
        gbc_idField.gridy = 0;
        formPanel.add(idField, gbc_idField);
        idField.setColumns(10);
        
        JLabel categoryLabel = new JLabel("Name:");
        GridBagConstraints gbc_categoryLabel = new GridBagConstraints();
        gbc_categoryLabel.insets = new Insets(0, 0, 5, 5);
        gbc_categoryLabel.anchor = GridBagConstraints.EAST;
        gbc_categoryLabel.gridx = 0;
        gbc_categoryLabel.gridy = 1;
        formPanel.add(categoryLabel, gbc_categoryLabel);
        
        categoryField = new JTextField();
        GridBagConstraints gbc_categoryField = new GridBagConstraints();
        gbc_categoryField.insets = new Insets(0, 0, 5, 0);
        gbc_categoryField.fill = GridBagConstraints.HORIZONTAL;
        gbc_categoryField.gridx = 1;
        gbc_categoryField.gridy = 1;
        formPanel.add(categoryField, gbc_categoryField);
        categoryField.setColumns(10);
        
        btnCreate = new JButton("Create");
        GridBagConstraints gbc_btnCreate = new GridBagConstraints();
        gbc_btnCreate.anchor = GridBagConstraints.WEST;
        gbc_btnCreate.insets = new Insets(0, 0, 5, 0);
        gbc_btnCreate.gridx = 1;
        gbc_btnCreate.gridy = 2;
        formPanel.add(btnCreate, gbc_btnCreate);
        
        //        // Add action listeners
                btnCreate.addActionListener(e -> handleAction("create"));
        
        btnUpdate = new JButton("Update");
        GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
        gbc_btnUpdate.insets = new Insets(0, 0, 5, 0);
        gbc_btnUpdate.anchor = GridBagConstraints.WEST;
        gbc_btnUpdate.gridx = 1;
        gbc_btnUpdate.gridy = 3;
        formPanel.add(btnUpdate, gbc_btnUpdate);
        btnUpdate.addActionListener(e -> handleAction("update"));
        
        btnDelete = new JButton("Delete");
        GridBagConstraints gbc_btnDelete = new GridBagConstraints();
        gbc_btnDelete.insets = new Insets(0, 0, 5, 0);
        gbc_btnDelete.anchor = GridBagConstraints.WEST;
        gbc_btnDelete.gridx = 1;
        gbc_btnDelete.gridy = 4;
        formPanel.add(btnDelete, gbc_btnDelete);
        btnDelete.addActionListener(e -> handleAction("delete"));
        
        btnClear = new JButton("Clear");
        btnClear.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		clearInputs();
        	}
        });
        
        GridBagConstraints gbc_btnClear = new GridBagConstraints();
        gbc_btnClear.anchor = GridBagConstraints.WEST;
        gbc_btnClear.insets = new Insets(0, 0, 5, 0);
        gbc_btnClear.gridx = 1;
        gbc_btnClear.gridy = 5;
        formPanel.add(btnClear, gbc_btnClear);
        
        messageLabel = new JLabel("");
        GridBagConstraints gbc_messageLabel = new GridBagConstraints();
        gbc_messageLabel.insets = new Insets(0, 0, 0, 5);
        gbc_messageLabel.gridx = 0;
        gbc_messageLabel.gridy = 9;
        formPanel.add(messageLabel, gbc_messageLabel);
        getContentPane().add(tableScrollPane, BorderLayout.CENTER);

//         Add a row selection listener
        catTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Get the selected row
                int selectedRow = catTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // Get data from the selected row
                	idField.setText((String) catTable.getValueAt(selectedRow, 0));
                    categoryField.setText((String) catTable.getValueAt(selectedRow, 1));
                }
            }
        });
    }

    private void handleAction(String action) {
   	
    	String id = idField.getText();
        String category = categoryField.getText();

        String endpoint = "";
        String method = "POST";
        String jsonInputString = "";
        
        //prep the action
        if (action.equals("create")) {
            endpoint = "http://localhost:8080/api/category/add";
            jsonInputString = "{ \"name\": \"" + category + "\" }";
        }
        else if (action.equals("update")) {
            endpoint = "http://localhost:8080/api/category/update";
            jsonInputString = "{\"id\": \"" + id + "\", \"name\": \"" + category + "\", \"updatedBy\": \"" + sessionUserName + "\"}";
        }
        else if (action.equals("delete")) {
            endpoint = "http://localhost:8080/api/category/delete";
            jsonInputString = "{\"id\": \"" + id + "\"}";
        } 
        else {
	        System.out.println("Unknown Action");
        }
       
        int result = JOptionPane.showConfirmDialog(null, 
				   "Do you want to proceed to " + action + " this?",
				   "Confirmation",
				   JOptionPane.YES_NO_OPTION,
				   JOptionPane.QUESTION_MESSAGE);
 
        //YES
        if(result == JOptionPane.YES_OPTION) {
        	try {
        		String response = ApiClient.sendRequest(endpoint, method, jsonInputString);
        		if (response.startsWith("200:") || response.startsWith("201:")) {
        			JOptionPane.showMessageDialog(
        					null, 
        					action.substring(0, 1).toUpperCase() + action.substring(1) + " successful", 
        					"Success", 
        					JOptionPane.INFORMATION_MESSAGE);
        			clearInputs();
        			fetchDataFromApi();
        		}
        	} catch (Exception e) {
        		JOptionPane.showMessageDialog(
        				null, 
        				"Cannot process your request. Please try again.", 
        				"Error", 
        				JOptionPane.INFORMATION_MESSAGE);
        	}
        }
    }
    
    private void fetchDataFromApi() {
        // Clear existing rows
        tableModel.setRowCount(0);

        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/category/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
            	response = response.substring(4);
            } 
            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                
                String id = jsonObject.optString("id");
                String categoryname = jsonObject.optString("name");
                String createdAt = jsonObject.optString("created_at");
                String updatedBy = jsonObject.optString("updatedBy");
                String updatedAt = jsonObject.optString("updatedOn");
                
                //System.out.print(id);
                // Add row to table model
                tableModel.addRow(new Object[]{id, categoryname, createdAt, updatedBy, updatedAt});
            }

        } catch (Exception e) {
        	messageLabel.setText("API error: " + e.getMessage());
        }
    }

    private void setSizeAndPosition() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        int width = (int) (screenSize.width * 0.8);
        int height = (int) (screenSize.height * 0.8);

        setSize(width, height);
        setLocationRelativeTo(null);
    }
    private void clearInputs() {
    	idField.setText("");
        categoryField.setText("");
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CategoriesFrame frame = new CategoriesFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
