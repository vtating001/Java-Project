package inventory_swing_1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

import inventory_swing_1_DataAccess.ApiClient;
import inventory_swing_1_DataAccess.SessionManager;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class CustomersFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private String sessionUserName = SessionManager.getInstance().getUsername();
    private JTable customerTable;
    private DefaultTableModel tableModel;
    private JTextField emailField;
    private JTextField idField;
    private JTextField mobileField;
    private JTextField fullnameField;
    private JLabel messageLabel;
    private JButton btnCreate;
    private JButton btnUpdate;
    private JButton btnClear;

    public CustomersFrame() {
        setTitle("Products");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initializeUI();
        setSizeAndPosition();
        fetchDataFromApi();
    }

    private void initializeUI() {
        getContentPane().setLayout(new BorderLayout());

        // Create panel for form and buttons
        JPanel formPanel = new JPanel();
        formPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
        GridBagLayout gbl_formPanel = new GridBagLayout();
        gbl_formPanel.columnWeights = new double[]{1.0, 0.0};
        formPanel.setLayout(gbl_formPanel);
        
        JLabel IDLabel = new JLabel("ID");
        GridBagConstraints gbc_IDLabel = new GridBagConstraints();
        gbc_IDLabel.insets = new Insets(0, 0, 5, 5);
        gbc_IDLabel.gridx = 0;
        gbc_IDLabel.gridy = 0;
        formPanel.add(IDLabel, gbc_IDLabel);

        // Add components to formPanel with different constraints

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;

        // Create the table
        String[] columnNames = {"ID", "Full Name", "Email", "Mobile", "Created At", "Updated By", "Updated At"};
        tableModel = new DefaultTableModel(columnNames, 0);
        customerTable = new JTable(tableModel);

        // Create a scroll pane for the table
        JScrollPane tableScrollPane = new JScrollPane(customerTable);

        // Add components to the frame
        getContentPane().add(formPanel, BorderLayout.WEST);
        
        idField = new JTextField();
        idField.setEditable(false);
        GridBagConstraints gbc_idField = new GridBagConstraints();
        gbc_idField.insets = new Insets(0, 0, 5, 0);
        gbc_idField.fill = GridBagConstraints.HORIZONTAL;
        gbc_idField.gridx = 1;
        gbc_idField.gridy = 0;
        formPanel.add(idField, gbc_idField);
        idField.setColumns(10);
        
        JLabel fullNameLabel = new JLabel("Full Name:");
        GridBagConstraints gbc_fullNameLabel = new GridBagConstraints();
        gbc_fullNameLabel.anchor = GridBagConstraints.EAST;
        gbc_fullNameLabel.insets = new Insets(0, 0, 5, 5);
        gbc_fullNameLabel.gridx = 0;
        gbc_fullNameLabel.gridy = 1;
        formPanel.add(fullNameLabel, gbc_fullNameLabel);
        
        fullnameField = new JTextField();
        GridBagConstraints gbc_fullnameField = new GridBagConstraints();
        gbc_fullnameField.insets = new Insets(0, 0, 5, 0);
        gbc_fullnameField.fill = GridBagConstraints.HORIZONTAL;
        gbc_fullnameField.gridx = 1;
        gbc_fullnameField.gridy = 1;
        formPanel.add(fullnameField, gbc_fullnameField);
        fullnameField.setColumns(10);
        
        JLabel emailLabel = new JLabel("Email:");
        GridBagConstraints gbc_emailLabel = new GridBagConstraints();
        gbc_emailLabel.insets = new Insets(0, 0, 5, 5);
        gbc_emailLabel.anchor = GridBagConstraints.EAST;
        gbc_emailLabel.gridx = 0;
        gbc_emailLabel.gridy = 2;
        formPanel.add(emailLabel, gbc_emailLabel);
        
        emailField = new JTextField();
        GridBagConstraints gbc_emailField = new GridBagConstraints();
        gbc_emailField.insets = new Insets(0, 0, 5, 0);
        gbc_emailField.fill = GridBagConstraints.HORIZONTAL;
        gbc_emailField.gridx = 1;
        gbc_emailField.gridy = 2;
        formPanel.add(emailField, gbc_emailField);
        emailField.setColumns(10);
        
        JLabel mobileLabel = new JLabel("Mobile:");
        GridBagConstraints gbc_mobileLabel = new GridBagConstraints();
        gbc_mobileLabel.insets = new Insets(0, 0, 5, 5);
        gbc_mobileLabel.anchor = GridBagConstraints.EAST;
        gbc_mobileLabel.gridx = 0;
        gbc_mobileLabel.gridy = 3;
        formPanel.add(mobileLabel, gbc_mobileLabel);
        
        mobileField = new JTextField();
        GridBagConstraints gbc_mobileField = new GridBagConstraints();
        gbc_mobileField.insets = new Insets(0, 0, 5, 0);
        gbc_mobileField.fill = GridBagConstraints.HORIZONTAL;
        gbc_mobileField.gridx = 1;
        gbc_mobileField.gridy = 3;
        formPanel.add(mobileField, gbc_mobileField);
        mobileField.setColumns(10);
        
        btnCreate = new JButton("Create");
        GridBagConstraints gbc_btnCreate = new GridBagConstraints();
        gbc_btnCreate.anchor = GridBagConstraints.WEST;
        gbc_btnCreate.insets = new Insets(0, 0, 5, 0);
        gbc_btnCreate.gridx = 1;
        gbc_btnCreate.gridy = 4;
        formPanel.add(btnCreate, gbc_btnCreate);
        
        //        // Add action listeners
                btnCreate.addActionListener(e -> handleAction("create"));
        
        btnUpdate = new JButton("Update");
        GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
        gbc_btnUpdate.insets = new Insets(0, 0, 5, 0);
        gbc_btnUpdate.anchor = GridBagConstraints.WEST;
        gbc_btnUpdate.gridx = 1;
        gbc_btnUpdate.gridy = 5;
        formPanel.add(btnUpdate, gbc_btnUpdate);
        btnUpdate.addActionListener(e -> handleAction("update"));
        
        btnClear = new JButton("Clear");
        btnClear.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		clearInputs();
        	}
        });
        
        GridBagConstraints gbc_btnClear = new GridBagConstraints();
        gbc_btnClear.anchor = GridBagConstraints.WEST;
        gbc_btnClear.insets = new Insets(0, 0, 5, 0);
        gbc_btnClear.gridx = 1;
        gbc_btnClear.gridy = 6;
        formPanel.add(btnClear, gbc_btnClear);
        
        messageLabel = new JLabel("");
        GridBagConstraints gbc_messageLabel = new GridBagConstraints();
        gbc_messageLabel.insets = new Insets(0, 0, 0, 5);
        gbc_messageLabel.gridx = 0;
        gbc_messageLabel.gridy = 10;
        formPanel.add(messageLabel, gbc_messageLabel);
        getContentPane().add(tableScrollPane, BorderLayout.CENTER);

//         Add a row selection listener
        customerTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Get the selected row
                int selectedRow = customerTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // Get data from the selected row
                	idField.setText((String) customerTable.getValueAt(selectedRow, 0));
                    fullnameField.setText((String) customerTable.getValueAt(selectedRow, 1));
                    emailField.setText((String) customerTable.getValueAt(selectedRow, 2));
                    mobileField.setText((String) customerTable.getValueAt(selectedRow, 3));
                }
            }
        });
    }

    private void handleAction(String action) {
    	
    	String id = idField.getText();
        String email = emailField.getText();
        String mobile = mobileField.getText();
        String fullname = fullnameField.getText();

        String endpoint = "";
        String method = "POST";
        String jsonInputString = "";
        
        //prep the action
        if (action.equals("create")) {
            endpoint = "http://localhost:8080/api/customer/add";
            jsonInputString = "{ \"name\": \"" + fullname + "\", \"mobile\": \"" + mobile + "\", \"email\": \"" + email + "\"}";
        }
        else if (action.equals("update")) {
        	System.out.print(sessionUserName);
            endpoint = "http://localhost:8080/api/customer/update";
            jsonInputString = "{\"id\": \"" + id + "\" , \"name\": \"" + fullname + "\", \"mobile\": \"" + mobile + "\", \"email\": \"" + email + "\", \"updatedBy\": \"" + sessionUserName + "\"}";
        }
        else {
	        System.out.println("Unknown Action");
        }
       
        int result = JOptionPane.showConfirmDialog(null, 
				   "Do you want to proceed to " + action + " this?",
				   "Confirmation",
				   JOptionPane.YES_NO_OPTION,
				   JOptionPane.QUESTION_MESSAGE);
        
        //YES
        if(result == JOptionPane.YES_OPTION) {
        	try {


        		String response = ApiClient.sendRequest(endpoint, method, jsonInputString);
        		if (response.startsWith("200:") || response.startsWith("201:")) {
        			JOptionPane.showMessageDialog(
        					null, 
        					action.substring(0, 1).toUpperCase() + action.substring(1) + " successful", 
        					"Success", 
        					JOptionPane.INFORMATION_MESSAGE);
        			clearInputs();
        			fetchDataFromApi();
        		}
        	} catch (Exception e) {
        		JOptionPane.showMessageDialog(
        				null, 
        				"Cannot process your request. Please try again.", 
        				"Error", 
        				JOptionPane.INFORMATION_MESSAGE);
        	}
        }
    }
    
    private void fetchDataFromApi() {
        // Clear existing rows
        tableModel.setRowCount(0);

        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/customer/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
            	response = response.substring(4);
            } 
            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                
                String id = jsonObject.optString("id");
                String fullname = jsonObject.optString("name");
                String mobile = jsonObject.optString("mobile");
                String email = jsonObject.optString("email");
                String createdAt = jsonObject.optString("timestamp");
                String updatedBy = jsonObject.optString("updatedBy");
                String updatedAt = jsonObject.optString("updatedOn");
                
                //System.out.print(id);
                // Add row to table model
                tableModel.addRow(new Object[]{id, fullname, email, mobile, createdAt, updatedBy, updatedAt});
            }

        } catch (Exception e) {
        	messageLabel.setText("API error: " + e.getMessage());
        }
    }

    private void setSizeAndPosition() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        int width = (int) (screenSize.width * 0.8);
        int height = (int) (screenSize.height * 0.8);

        setSize(width, height);
        setLocationRelativeTo(null);
    }
    private void clearInputs() {
    	idField.setText("");
        emailField.setText("");
        mobileField.setText("");
        fullnameField.setText("");
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomersFrame frame = new CustomersFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
