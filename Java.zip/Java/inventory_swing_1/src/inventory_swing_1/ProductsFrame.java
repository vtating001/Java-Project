package inventory_swing_1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

import inventory_swing_1_DataAccess.ApiClient;
import inventory_swing_1_DataAccess.SessionManager;
import javax.swing.JComboBox;

public class ProductsFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private String sessionUserName = SessionManager.getInstance().getUsername();
    private JTable userTable;
    private DefaultTableModel tableModel;
    private JTextField nameField;
    private JTextField idField;
    private JTextField priceField;
    private JTextField quantityField;
    private JLabel messageLabel;
    private JButton btnCreate;
    private JButton btnUpdate;
    private JButton btnDelete;
    private JButton btnClear;
    private JLabel categoryLabel;
    private JComboBox<Category> categoryCB;
    private List<Category> categories = new ArrayList<>();
    private JTextField descriptionField;

    public ProductsFrame() {
        setTitle("Products");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initializeUI();
        setSizeAndPosition();
        fetchDataFromApi();
        fetchDataFromApitoComboBox();
    }

    private void initializeUI() {
        getContentPane().setLayout(new BorderLayout());

        // Create panel for form and buttons
        JPanel formPanel = new JPanel();
        formPanel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
        GridBagLayout gbl_formPanel = new GridBagLayout();
        gbl_formPanel.columnWeights = new double[]{1.0, 1.0};
        formPanel.setLayout(gbl_formPanel);
        
        JLabel IDLabel = new JLabel("ID");
        GridBagConstraints gbc_IDLabel = new GridBagConstraints();
        gbc_IDLabel.insets = new Insets(0, 0, 5, 5);
        gbc_IDLabel.gridx = 0;
        gbc_IDLabel.gridy = 0;
        formPanel.add(IDLabel, gbc_IDLabel);

        // Add components to formPanel with different constraints

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.EAST;

        // Create the table
        String[] columnNames = {"ID", "Name", "Category", "Price", "Quantity", "Description", "Created At", "Updated By", "Updated At"};
        tableModel = new DefaultTableModel(columnNames, 0);
        userTable = new JTable(tableModel);

        // Create a scroll pane for the table
        JScrollPane tableScrollPane = new JScrollPane(userTable);

        // Add components to the frame
        getContentPane().add(formPanel, BorderLayout.WEST);
        
        idField = new JTextField();
        idField.setEditable(false);
        GridBagConstraints gbc_idField = new GridBagConstraints();
        gbc_idField.insets = new Insets(0, 0, 5, 0);
        gbc_idField.fill = GridBagConstraints.HORIZONTAL;
        gbc_idField.gridx = 1;
        gbc_idField.gridy = 0;
        formPanel.add(idField, gbc_idField);
        idField.setColumns(10);
        
        JLabel NameLabel = new JLabel("Name:");
        GridBagConstraints gbc_NameLabel = new GridBagConstraints();
        gbc_NameLabel.insets = new Insets(0, 0, 5, 5);
        gbc_NameLabel.anchor = GridBagConstraints.EAST;
        gbc_NameLabel.gridx = 0;
        gbc_NameLabel.gridy = 1;
        formPanel.add(NameLabel, gbc_NameLabel);
        
        nameField = new JTextField();
        GridBagConstraints gbc_nameField = new GridBagConstraints();
        gbc_nameField.insets = new Insets(0, 0, 5, 0);
        gbc_nameField.fill = GridBagConstraints.HORIZONTAL;
        gbc_nameField.gridx = 1;
        gbc_nameField.gridy = 1;
        formPanel.add(nameField, gbc_nameField);
        nameField.setColumns(10);
        
        categoryLabel = new JLabel("Category:");
        GridBagConstraints gbc_categoryLabel = new GridBagConstraints();
        gbc_categoryLabel.anchor = GridBagConstraints.EAST;
        gbc_categoryLabel.insets = new Insets(0, 0, 5, 5);
        gbc_categoryLabel.gridx = 0;
        gbc_categoryLabel.gridy = 2;
        formPanel.add(categoryLabel, gbc_categoryLabel);
        
        categoryCB = new JComboBox<Category>();
        GridBagConstraints gbc_categoryCB = new GridBagConstraints();
        gbc_categoryCB.insets = new Insets(0, 0, 5, 0);
        gbc_categoryCB.fill = GridBagConstraints.HORIZONTAL;
        gbc_categoryCB.gridx = 1;
        gbc_categoryCB.gridy = 2;
        formPanel.add(categoryCB, gbc_categoryCB);
        
        JLabel quantityLabel = new JLabel("Quantity:");
        GridBagConstraints gbc_quantityLabel = new GridBagConstraints();
        gbc_quantityLabel.anchor = GridBagConstraints.EAST;
        gbc_quantityLabel.insets = new Insets(0, 0, 5, 5);
        gbc_quantityLabel.gridx = 0;
        gbc_quantityLabel.gridy = 3;
        formPanel.add(quantityLabel, gbc_quantityLabel);
        
        quantityField = new JTextField();
        GridBagConstraints gbc_quantityField = new GridBagConstraints();
        gbc_quantityField.insets = new Insets(0, 0, 5, 0);
        gbc_quantityField.fill = GridBagConstraints.HORIZONTAL;
        gbc_quantityField.gridx = 1;
        gbc_quantityField.gridy = 3;
        formPanel.add(quantityField, gbc_quantityField);
        quantityField.setColumns(10);
        
        JLabel priceLabel = new JLabel("Price:");
        GridBagConstraints gbc_priceLabel = new GridBagConstraints();
        gbc_priceLabel.insets = new Insets(0, 0, 5, 5);
        gbc_priceLabel.anchor = GridBagConstraints.EAST;
        gbc_priceLabel.gridx = 0;
        gbc_priceLabel.gridy = 4;
        formPanel.add(priceLabel, gbc_priceLabel);
        
        priceField = new JTextField();
        GridBagConstraints gbc_priceField = new GridBagConstraints();
        gbc_priceField.insets = new Insets(0, 0, 5, 0);
        gbc_priceField.fill = GridBagConstraints.HORIZONTAL;
        gbc_priceField.gridx = 1;
        gbc_priceField.gridy = 4;
        formPanel.add(priceField, gbc_priceField);
        priceField.setColumns(10);
        
        JLabel descriptionLabel = new JLabel("Description:");
        GridBagConstraints gbc_descriptionLabel = new GridBagConstraints();
        gbc_descriptionLabel.anchor = GridBagConstraints.EAST;
        gbc_descriptionLabel.insets = new Insets(0, 0, 5, 5);
        gbc_descriptionLabel.gridx = 0;
        gbc_descriptionLabel.gridy = 5;
        formPanel.add(descriptionLabel, gbc_descriptionLabel);
        
        descriptionField = new JTextField();
        descriptionField.setColumns(10);
        GridBagConstraints gbc_descriptionField = new GridBagConstraints();
        gbc_descriptionField.insets = new Insets(0, 0, 5, 0);
        gbc_descriptionField.fill = GridBagConstraints.HORIZONTAL;
        gbc_descriptionField.gridx = 1;
        gbc_descriptionField.gridy = 5;
        formPanel.add(descriptionField, gbc_descriptionField);
        
        btnCreate = new JButton("Create");
        GridBagConstraints gbc_btnCreate = new GridBagConstraints();
        gbc_btnCreate.anchor = GridBagConstraints.WEST;
        gbc_btnCreate.insets = new Insets(0, 0, 5, 0);
        gbc_btnCreate.gridx = 1;
        gbc_btnCreate.gridy = 6;
        formPanel.add(btnCreate, gbc_btnCreate);
        
        //        // Add action listeners
                btnCreate.addActionListener(e -> handleAction("create"));
        
        btnUpdate = new JButton("Update");
        GridBagConstraints gbc_btnUpdate = new GridBagConstraints();
        gbc_btnUpdate.insets = new Insets(0, 0, 5, 0);
        gbc_btnUpdate.anchor = GridBagConstraints.WEST;
        gbc_btnUpdate.gridx = 1;
        gbc_btnUpdate.gridy = 7;
        formPanel.add(btnUpdate, gbc_btnUpdate);
        btnUpdate.addActionListener(e -> handleAction("update"));
        
        btnDelete = new JButton("Delete");
        GridBagConstraints gbc_btnDelete = new GridBagConstraints();
        gbc_btnDelete.insets = new Insets(0, 0, 5, 0);
        gbc_btnDelete.anchor = GridBagConstraints.WEST;
        gbc_btnDelete.gridx = 1;
        gbc_btnDelete.gridy = 8;
        formPanel.add(btnDelete, gbc_btnDelete);
        btnDelete.addActionListener(e -> handleAction("delete"));
        
        btnClear = new JButton("Clear");
        btnClear.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		clearInputs();
        	}
        });
        
        GridBagConstraints gbc_btnClear = new GridBagConstraints();
        gbc_btnClear.anchor = GridBagConstraints.WEST;
        gbc_btnClear.insets = new Insets(0, 0, 5, 0);
        gbc_btnClear.gridx = 1;
        gbc_btnClear.gridy = 9;
        formPanel.add(btnClear, gbc_btnClear);
        
        messageLabel = new JLabel("");
        GridBagConstraints gbc_messageLabel = new GridBagConstraints();
        gbc_messageLabel.insets = new Insets(0, 0, 0, 5);
        gbc_messageLabel.gridx = 0;
        gbc_messageLabel.gridy = 12;
        formPanel.add(messageLabel, gbc_messageLabel);
        getContentPane().add(tableScrollPane, BorderLayout.CENTER);

//         Add a row selection listener
        userTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Get the selected row
                int selectedRow = userTable.getSelectedRow();
                if (selectedRow >= 0) {
                	 int index = findIndexByName(categories, (String) userTable.getValueAt(selectedRow, 2));
                	// Get data from the selected row
                	idField.setText((String) userTable.getValueAt(selectedRow, 0));
                    nameField.setText((String) userTable.getValueAt(selectedRow, 1));
               	 	categoryCB.setSelectedIndex(index);
                    priceField.setText((String) userTable.getValueAt(selectedRow, 3));
                    quantityField.setText((String) userTable.getValueAt(selectedRow, 4));
                    descriptionField.setText((String) userTable.getValueAt(selectedRow, 5));
                }
            }
        });
    }

    private void handleAction(String action) {
    	
    	   // Get selected category
        Category selectedCategory = (Category) categoryCB.getSelectedItem();
       
    	String id = idField.getText();
        String name = nameField.getText();
        String category = selectedCategory.getId();
        String price = priceField.getText();
        String quantity = quantityField.getText();
        String description = descriptionField.getText();
        
        String endpoint = "";
        String method = "POST";
        String jsonInputString = "";
        
//        System.out.print(category);
        //prep the action
        if (action.equals("create")) {
            endpoint = "http://localhost:8080/api/product/add";
            jsonInputString = "{\n" +
                    "    \"name\": \""+ name +"\",\n" +
                    "    \"price\": \""+ price +"\",\n" +
                    "    \"quantity\": \""+ quantity + "\",\n" +
                    "    \"description\": \""+ description +"\",\n" +
                    "    \"category\": {\n" +
                    "        \"id\": \""+ category + "\"\n" +
                    "    }\n" +
                    "}";
        }
        else if (action.equals("update")) {
        	System.out.print(sessionUserName);
            endpoint = "http://localhost:8080/api/product/update";
            jsonInputString = "{\n" +
                    "    \"id\": \""+ id +"\",\n" +
                    "    \"name\": \""+ name +"\",\n" +
                    "    \"price\": \""+ price +"\",\n" +
                    "    \"quantity\": \""+ quantity + "\",\n" +
                    "    \"description\": \""+ description +"\",\n" +
                    "    \"updatedBy\": \""+ sessionUserName +"\",\n" +
                    "    \"category\": {\n" +
                    "        \"id\": \""+ category + "\"\n" +
                    "    }\n" +
                    "}";
        }
        else if (action.equals("delete")) {
            endpoint = "http://localhost:8080/api/product/delete";
            jsonInputString = "{\"id\": \"" + id + "\"}";
        } 
        else {
	        System.out.println("Unknown Action");
        }
       
        int result = JOptionPane.showConfirmDialog(null, 
				   "Do you want to proceed to " + action + " this?",
				   "Confirmation",
				   JOptionPane.YES_NO_OPTION,
				   JOptionPane.QUESTION_MESSAGE);
        
        //YES
        if(result == JOptionPane.YES_OPTION) {
        	try {
        		String response = ApiClient.sendRequest(endpoint, method, jsonInputString);
        		if (response.startsWith("200:") || response.startsWith("201:")) {
        			JOptionPane.showMessageDialog(
        					null, 
        					action.substring(0, 1).toUpperCase() + action.substring(1) + " successful", 
        					"Success", 
        					JOptionPane.INFORMATION_MESSAGE);
        			clearInputs();
        			fetchDataFromApi();
        		}
        	} catch (Exception e) {
        		JOptionPane.showMessageDialog(
        				null, 
        				"Cannot process your request. Please try again.", 
        				"Error", 
        				JOptionPane.INFORMATION_MESSAGE);
        	}
        }
    }
    
    private void fetchDataFromApi() {
        // Clear existing rows
        tableModel.setRowCount(0);

        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/product/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
            	response = response.substring(4);
            } 
            else {
                // Handle non-200 responses
                throw new IOException("Failed to fetch data. HTTP response code: " + response);
            }
            
            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);

            // Loop through JSON array and populate the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                JSONObject categoryObject = jsonObject.optJSONObject("category");
                
                String id = jsonObject.optString("id");
                String name = jsonObject.optString("name");
                String price = jsonObject.optString("price");
                String quantity = jsonObject.optString("quantity");
                String description = jsonObject.optString("description");
                String createdAt = jsonObject.optString("timestamp");
                String updatedBy = jsonObject.optString("updatedBy");
                String updatedAt = jsonObject.optString("updatedOn");
                String categoryName = categoryObject != null ? categoryObject.optString("name", "N/A") : "N/A";

                tableModel.addRow(new Object[]{id, name, categoryName, price, quantity,description, createdAt, updatedBy, updatedAt});
            }

        } catch (Exception e) {
        	messageLabel.setText("API error: " + e.getMessage());
        }
    }
    private void fetchDataFromApitoComboBox() {
        // Define API endpoint
        String apiEndpoint = "http://localhost:8080/api/category/all";

        try {
            // Fetch data from API
            String response = ApiClient.sendRequest(apiEndpoint, "GET", null);
            if (response.startsWith("200:")) {
            	response = response.substring(4);
            }
            else {
                // Handle non-200 responses
                throw new IOException("Failed to fetch data. HTTP response code: " + response);
            }
            // Parse JSON response
            JSONArray jsonArray = new JSONArray(response);
            
            // Loop through JSON array and populate the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                
                String id = jsonObject.optString("id");
                String name = jsonObject.optString("name");
              
                categories.add(new Category(id,name));
            }
            // Populate JComboBox
            DefaultComboBoxModel<Category> model = new DefaultComboBoxModel<>(categories.toArray(new Category[0]));
            categoryCB.setModel(model);

        } catch (Exception e) {
        	messageLabel.setText("API error: " + e.getMessage());
        }
    }
    private void clearInputs() {
    	idField.setText("");
        nameField.setText("");
        priceField.setText("");
        descriptionField.setText("");
        quantityField.setText("");
    }
    public static class Category {
    	private String id;
    	private String name;
		public Category(String id, String name) {
			super();
			this.id = id;
			this.name = name;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		  @Override
		    public String toString() {
		        return name; // This is what will be displayed in the JComboBox
		    }
		
    }
    public static int findIndexByName(List<Category> categories, String name) {
        for (int i = 0; i < categories.size(); i++) {
            if (categories.get(i).getName().equals(name)) {
                return i;
            }
        }
        return -1; // Not found
    }
    private void setSizeAndPosition() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        int width = (int) (screenSize.width * 0.8);
        int height = (int) (screenSize.height * 0.8);

        setSize(width, height);
        setLocationRelativeTo(null);
    }
    

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProductsFrame frame = new ProductsFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


}
