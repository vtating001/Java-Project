package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@SpringBootTest
class RestcrudApplicationTests {
	
	// test to see if ok adding record
	// create record, check if firstname exists
	// do you have a way to findByFirstName?
	// findBy...... <--- repository
	// findByFirstName <----- not exists in JPA Repository
	
	// reference to employeeService
	@Autowired
	EmployeeService es;
		
	// reference to employeeRepository
	@Autowired
	EmployeeRepository er;
	
	@Test
	void testAddEmployee() {
		
		Employee newEmp = new Employee();
		newEmp.setFirstName("dummyf");
		newEmp.setLastName("dummyl");
		newEmp.setEmail("dummye");
		newEmp.setDepartment("dummyd");
		es.saveEmployee(newEmp);
		
		assertNotNull(er.findByFirstName(newEmp.getFirstName()));
		
		
	}
	
	
	
	
	

}
